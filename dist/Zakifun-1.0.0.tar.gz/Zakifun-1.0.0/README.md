# Zakifun
public package
# instalation
```py
import Zakifun

Zakifun.test()
```