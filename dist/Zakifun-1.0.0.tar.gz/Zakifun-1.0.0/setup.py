import setuptools
from setuptools import setup

setup(
    name='Zakifun',
    version='1.0.0',
    description='zakifun for you',
    url='https://github.com/muhammadzaki693/Zakifun.git',
    author='muhammadzaki693',
    author_email='rzaki9353@gmail.com',
    license='unlicense',
    packages=['Zakifun'],
    zip_safe=False
)