# Zakifun
a small package
# install

```
pip install Zakifun
```

and import the name package